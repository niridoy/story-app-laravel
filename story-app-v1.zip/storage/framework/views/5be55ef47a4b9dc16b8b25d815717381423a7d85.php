<?php $__env->startPush('styles'); ?>
    <style>
        .pagination {
            float: right;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="row mb-3">
                <div class="col-md-6 col-lg-7">
                    
                </div>
                <div class="col-md-6 col-lg-5">
                    <form action="<?php echo e(route('stories.index')); ?>" method="GET" style="display: inline">
                        <div class="input-group">
                            <input type="text" class="form-control" name="search_keyword" value="<?php echo e(Request::has('search_keyword') ? Request::get('search_keyword') : ''); ?>" placeholder="Type and click on search button" aria-label="Type and click on search button" aria-describedby="button-addon2">
                            <button class="btn btn-outline-secondary" type="submit" id="button-addon2"> Search</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $Stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-10">
                <div class="card border-secondary mb-3">
                    <div class="card-header">
                        <h5><?php echo e($story->title); ?></h5>
                        <p>By <b><?php echo e($story->created_by_user->name); ?></b> on <b><?php echo e($story->show_published_date); ?></b> </p>
                    </div>
                    <div class="card-body text-justify">
                        <?php echo e($story->body); ?>

                    </div>
                    <div class="card-footer">
                        <div class="row">
                            <div class="col-md-6">
                                <a href="<?php echo e(route('stories.show', $story->id)); ?>?xml=1" target="_blank" class="btn btn-secondary">XML</a>
                                <a href="<?php echo e(route('stories.show', $story->id)); ?>" target="_blank" class="btn btn-secondary">JSON</a>
                            </div>
                            <div class="col-md-6 text-right">
                                <?php if(auth()->guard()->check()): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update', 'delete'], $story)): ?>
                                        <a href="<?php echo e(route('stories.edit', $story->id)); ?>" class="btn btn-primary">Edit</a>
                                        <button type="button" data-id=<?php echo e($story->id); ?> class="btn btn-danger delete-button">Delete</button>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Not Available')); ?></div>
                <div class="card-body"> Story Not Available ! </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="col-md-10">
            <div class="row">
                <div class="col-md-4">
                    <p>Showing <?php echo e($Stories->currentPage() * 2 - 1); ?> to <?php echo e($Stories->currentPage() * 2); ?>  out of  <?php echo e($Stories->total()); ?> </p>
                </div>
                <div class="col-md-8 text-right">
                    <?php echo e($Stories->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('layouts._delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function(){
            $(document).on('click','.delete-button',function(){
                let storyId = $(this).attr('data-id');
                let url = '<?php echo e(route('stories.index')); ?>' + '/' + storyId ;
                $('#delete_modal_form').attr('action',url);
                $('#delete_modal').modal('show');
            })
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Server\htdocs\laravel\story-laravel\resources\views/story/index.blade.php ENDPATH**/ ?>